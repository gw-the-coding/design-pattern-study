package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here

        ShapeManager sm = new ShapeManager();

        sm.regShape(new Triangle());
        sm.regShape(new Circle());
        sm.regShape(new Rect());

        //데코레이터 패턴
        sm.regShape(new ColorShape(new Rect(), "RED"));
        //어댑터 패턴
        sm.regShape(new TextObjectAdapter(new TextView("가나다라")));
        sm.regShape(new TextClassAdapter(("abcd")));
        sm.drawShape();




        //triangle!!!
        //rect!!!
        //circle!!!


    }
}

