package com.company;
import java.util.ArrayList;
import java.util.Collection;

public class ShapeManager {

    private Collection<Shape> shapecollect;

    public ShapeManager()
    {
        shapecollect = new ArrayList<Shape>();
    }
    public void regShape(Shape s)
    {
        shapecollect.add(s);
    }
    public void drawShape()
    {
        for(Shape s : shapecollect)
        {
            s.draw();
        }
    }

}
