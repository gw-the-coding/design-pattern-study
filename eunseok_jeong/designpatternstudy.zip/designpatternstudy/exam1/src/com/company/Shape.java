package com.company;

public interface Shape {
    public void draw();
    public void changesize();
    public void changelocation();
}

class Triangle implements Shape{

    public Triangle()
    {

    }
    @Override
    public void draw() {
        System.out.print("Triangle!!!");
        System.out.println();
    }

    @Override
    public void changesize() {

    }

    @Override
    public void changelocation() {

    }
}

class Rect implements Shape{

    public Rect(){

    }
    @Override
    public void draw() {
        System.out.print("Rect!!!");
        System.out.println();
    }

    @Override
    public void changesize() {

    }

    @Override
    public void changelocation() {

    }
}
class Circle implements Shape{

    public Circle()
    {

    }
    @Override
    public void draw() {
        System.out.print("Circle!!!");
        System.out.println();
    }

    @Override
    public void changesize() {

    }

    @Override
    public void changelocation() {

    }
}

class ColorShape implements Shape {
    public ColorShape(Shape shape, String color)
    {
        this.s = shape;
        this.color = color;
    }

    private Shape s;
    private String color;

    @Override
    public void draw() {
        System.out.print(color);
        s.draw();
    }

    @Override
    public void changesize() {

    }

    @Override
    public void changelocation() {

    }
}