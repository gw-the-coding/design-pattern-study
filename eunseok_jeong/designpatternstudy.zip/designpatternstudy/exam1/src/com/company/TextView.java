package com.company;


interface Textv {

    void show();
}

public class TextView implements Textv{

    private String data;

    public TextView(String s)
    {
        this.data = s;
    }

    public void show()
    {
        System.out.println("TEXT :" + data);
    }
}



//객체 어댑터
class TextObjectAdapter implements Shape {


    private Textv tv;
    public TextObjectAdapter(Textv tv)
    {
        this.tv = tv;
    }
    public void changeTextv(Textv tv)
    {
        this.tv = tv;
    }
    @Override
    public void draw() {
        tv.show();
    }
    @Override
    public void changesize() {

    }

    @Override
    public void changelocation() {

    }
}
//클래스 어댑터
class TextClassAdapter extends TextView implements Shape {

    public TextClassAdapter(String s)
    {
        super(s);
    }

    @Override
    public void draw() {
        super.show();
    }
    @Override
    public void changesize() {

    }

    @Override
    public void changelocation() {

    }
}