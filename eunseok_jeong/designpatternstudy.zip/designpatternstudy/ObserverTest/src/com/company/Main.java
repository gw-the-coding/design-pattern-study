package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here

        EventSource es = new EventSource();
        ResponseHandler rh = new ResponseHandler();

        es.addObserver(rh);
        es.addObserver(new ResponseHandler1());

        Thread thread = new Thread(es);
        thread.start();
    }
}
