package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Observable;

public class EventSource extends Observable implements Runnable {

    @Override
    public void run()
    {
        try
        {
            InputStreamReader isr = new InputStreamReader(System.in);
            BufferedReader br = new BufferedReader(isr);
            String response = "";
            while(!response.contentEquals("exit"))
            {
                String tmp = br.readLine();
                if(!tmp.contentEquals(response))
                {
                    response = tmp;
                    setChanged();
                }


                notifyObservers(response);
            }
            this.deleteObservers();

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
