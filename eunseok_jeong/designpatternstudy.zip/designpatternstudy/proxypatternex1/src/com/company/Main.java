package com.company;

import java.util.ArrayList;
import java.util.Collection;

public class Main {

    public static void main(String[] args) {
	// write your code here

//        BitmapImage bi = new BitmapImage("/Users/Mercytin-Jeong/IdeaProjects/proxypatternex1/pichu.jpg");
//
//        bi.loadimage();
//        bi.draw();
//
//        Collection<BitmapImage> col_bi = new ArrayList<>();
//
//        for (int i =0; i< 100; ++i) {
//            col_bi.add(new );
//        }
//        for (BitmapImage bimg: col_bi
//             ) {
//            bimg.draw();
//
//        }

        ProxyImage pi = new ProxyImage("/Users/Mercytin-Jeong/IdeaProjects/proxypatternex1/pichu.jpg");

        pi.draw();


        for (int i=0; i<100; ++i)
        {
            pi.draw();
        }



    }
}
