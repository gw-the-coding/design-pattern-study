package com.company;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class BitmapImage implements Image
{
    private String filepath;
    private BufferedImage img;

    BitmapImage(String filepath)
    {
        this.filepath = filepath;
    }

    public void loadimage()
    {
        try{
            this.img = ImageIO.read(new File(filepath));
        }
        catch (Exception ex)
        {

        }
    }

    @Override
    public void draw()
    {

        //"/Users/Mercytin-Jeong/IdeaProjects/proxypatternex1/pichu.jpg"
            DisplayImage di = new DisplayImage(img);

    }


}

class ProxyImage implements Image
{
    private String filepath;
    private BitmapImage img;

    public ProxyImage(String fp)
    {
        this.filepath = fp;
    }

    @Override
    public void draw()
    {
        if (img==null)
        {

            this.img = new BitmapImage(filepath);
            img.loadimage();
        }
        img.draw();

    }
}
